# Gökçesu Terme
# 2453587
def load_table(file_path):
    table = []
    # Open the file and process each line and load the table
    with open(file_path, 'r') as file:

        for line in file:
            # Check if the line contains an array row
            if line.startswith('{') and line.endswith('},\n'):
                # Extract the characters between curly braces, split by ',', and remove the single quotes
                row = line[1:-3].split(',')
                row = [char.strip().strip("'") for char in row]
                table.append(row)

    return table


def generate_key(plaintext, key):
    # generate key, if the key is shorter than the plain text pad it
    # till its has the same size with the plain text
    key_length = len(key)
    repeated_key = ""  # repeated key is for the final key that is going to be used.
    for i in range(len(plaintext)):
        repeated_key += key[i % key_length]

    repeated_key = repeated_key.replace(" ", "").upper()
    return repeated_key


def encrypt_phase1(plaintext, key, conversion_table):
    encrypted_text = ""

    # calculate the acii value of each char with the func "ord"
    for p_char, k_char in zip(plaintext, key):
        row_index = ord(k_char) - 65
        col_index = ord(p_char) - 65

        # Access the conversion table to get the encrypted character
        # calculate the encrypted_char from the indexes founded above
        # replace into indexes of the conversion table
        encrypted_char = conversion_table[row_index][col_index]
        # add the ciphertext's chars to the string encrypted_text
        encrypted_text += encrypted_char

    return encrypted_text


def split_string(input_str):

    # if the string contains odd length, pad with 0
    if len(input_str) % 2 != 0:
        input_str += '0'
    midpoint = len(input_str) // 2
    first_half = input_str[:midpoint]  # first half is before the midpoint
    second_half = input_str[midpoint:]  # second half is after the midpoint

    return first_half, second_half  # return both of them


def encrypt_phase2(first_half, second_half):
    result = ''
    for char1, char2 in zip(first_half, second_half):
        result += char1 + char2  # combine the first and the  second halves to get the result

    return result


def decrypt_phase2(plain_text):
    # this phase is the reverse phase of the encrypt_phase2
    even_group = ""
    odd_group = ""
    for i, char in enumerate(plain_text):
        if i % 2 == 0:
            even_group += char  # all chars that belongs to the even numbered indexes will give us the group 1
        else:
            odd_group += char  # all chars that belongs to the odd numbered indexes will give us the group 1

    print("group-1:", even_group)
    print("group-2:", odd_group)
    return even_group + odd_group  # return the result = group 2 appended to the end of the group 1


def decrypt_phase1(ciphertext, key, table):
    # this phase is the reverse phase of the encrypt_phase1
    print("Decryption Phase-1")
    ciphertext = ciphertext.replace(" ", "").upper()  # make upper and trim if not already
    print("Input text,", ciphertext)  # get the input ciphertext from the user

    plain_text = ""  # create an empty string called plain_text that is going to be filled with calculations below
    for p_char, k_char in zip(ciphertext, key):
        row_index = ord(k_char) - 65  # get the row index with the user key's char's ascii values - 65
        col_index = table[row_index].index(p_char)  # search in the table in the row index calculated above
        # and in that row find the plain text's char's columns index.
        plain_text_char = chr(col_index + 65)  # add 65 to find the char
        plain_text += plain_text_char  # append plain_text_char to the end of the string plain_text to get the result

    return plain_text


def check_string_length(input_text, key):

    if len(key) > len(input_text):
        return 0
    else:
        return 1

# all the operations will be done inside the menu function


def main():
    table = load_table("table.txt")  # load the conversion table
    option = 0
    while option != 3:
        print("\n")
        print("Simple Cipher")
        print("[1] Encrypt")
        print("[2] Decrypt")
        print("[3] Exit")
        option = int(input("Selection: "))  # get the selection from user

        # if 1 do all the encryption phase
        if option == 1:
            user_plain_text = input("Enter text: ")  # get the plain text from the user
            plain_text = user_plain_text.replace(" ", "").upper()  # trim and make them upper
            user_key = input("Enter key : ")  # get the key from the user
            key = generate_key(plain_text, user_key)  # generate the key properly
            print("************************************ Encryption ************************************ ")
            print("\n")
            print("Encrypting Phase-1")
            print("Plaintext:", plain_text)
            print("Key:", key)
            ciphertext_phase1 = encrypt_phase1(plain_text, key, table)
            print("Output (phase -1): ", ciphertext_phase1)

            print("\n")

            print("Encrypting Phase-2")
            print("Input text", ciphertext_phase1)
            first_half, second_half = split_string(ciphertext_phase1)  # calculate the first and second group
            # with the help of the split_string function
            print("group-1: ", first_half)
            print("group-2: ", second_half)

            ciphertext_phase2 = encrypt_phase2(first_half, second_half)  # combine the calculated groups
            ciphertext_phase2_final = ciphertext_phase2.rstrip('0/0')  # delete 0 if the string has padded with 0 before
            # with the help of the "rstrip" function. This function deletes all the zero and null chars in the string
            print("Ciphertext: ", ciphertext_phase2_final)
            print("************************************************************************************ ")

        elif option == 2:
            print("************************************ Decryption ************************************ ")
            print("Decryption phase-2")
            user_plain_text = input("input text")
            plain_text = user_plain_text.replace(" ", "").upper()
            ciphertext_phase2 = decrypt_phase2(plain_text)
            print("Output (phase-2): ", ciphertext_phase2)

            print("\n")
            user_key = input("Enter key : ")
            key = generate_key(plain_text, user_key)
            ciphertext_phase1 = decrypt_phase1(ciphertext_phase2, key, table)
            print("Plaintext: ", ciphertext_phase1)
            print("************************************************************************************* ")

        elif option == 3:
            break
        else:
            print("Invalid selection")  # in case user enters sth different than 1, 2 ,or 3


# Call the main function
if __name__ == "__main__":
    main()
